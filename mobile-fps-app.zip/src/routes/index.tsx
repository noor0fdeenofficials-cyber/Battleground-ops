import { createFileRoute } from "@tanstack/react-router";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Mobile FPS - Landscape Touch Shooter" },
      {
        name: "description",
        content:
          "Play Mobile FPS: a landscape touch-controlled 3D shooter with team deathmatch and battle royale modes, packaged for Android.",
      },
      { property: "og:title", content: "Mobile FPS - Landscape Touch Shooter" },
      {
        property: "og:description",
        content:
          "Landscape 3D mobile shooter with dual-stick touch controls, TDM and battle royale modes.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Index,
});

function Index() {
  return (
    <main className="fixed inset-0 bg-background">
      <h1 className="sr-only">Mobile FPS - landscape touch shooter</h1>
      <iframe
        src="/game/index.html"
        title="Mobile FPS game"
        className="h-full w-full border-0"
        allow="fullscreen; autoplay; accelerometer; gyroscope"
      />
    </main>
  );
}
