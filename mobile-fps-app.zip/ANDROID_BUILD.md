# Building the Android APK

The game lives in `public/game/` (self-contained: `index.html` + a local copy of
three.js, so it runs fully offline inside the app). The Android wrapper is
Capacitor, already configured in `capacitor.config.ts` and `android/`.

Orientation is locked to landscape natively via
`android:screenOrientation="sensorLandscape"` in
`android/app/src/main/AndroidManifest.xml`, and all controls (joystick, look
area, shoot / reload / jump, mode buttons) use `touchstart` + `pointerdown`
handlers with `passive: false`, so they respond to touch immediately.

## Requirements (on your own machine)

- Java JDK 21
- Android Studio (Android SDK 35 + build tools)

## Build steps

```bash
npm install
npx cap sync android        # copies public/game into the native project
cd android
./gradlew assembleDebug     # debug APK
```

Output: `android/app/build/outputs/apk/debug/app-debug.apk`

For a release APK:

```bash
cd android
./gradlew assembleRelease
```

Then sign it with your keystore (`apksigner sign --ks my-key.jks ...`).

Or simply open the `android/` folder in Android Studio and use
Build > Build Bundle(s) / APK(s) > Build APK(s).

## After editing the game

Re-run `npx cap sync android` so the native assets pick up your changes.
